package xyz.bibiyes.goodlearnai.dto;

import lombok.Data;

/**
     * @author Mouse Sakura
     */
@Data
public class LoginFrom {
    private String userEmail;
    private String userPassword;
}
