package xyz.bibiyes.goodlearnai.dto;

import lombok.Data;

@Data
public class EmailFrom {
    private String email;
}
