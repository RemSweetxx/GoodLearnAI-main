package xyz.bibiyes.goodlearnai.service;

public interface AIService {
    String getAI(String str);
}
