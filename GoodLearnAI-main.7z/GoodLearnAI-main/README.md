# SpringBoot2+Vue3实现AI好助学
以下是如何在本设备上调试的指南

## mysql 部分
1. 创建一个名为good_learn_ai的数据库
2. 在项目的resource找到一个名为`good_learn_ai.sql`的文件导入到数据中

## spring boot 部分
1. 在项目配置文件配置数据用户名
2. 在项目配置文件中配置数据库密码